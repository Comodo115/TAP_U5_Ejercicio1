package mx.edu.ittepic.tap_u5_ejercicio1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var numero = 9
    var sueldo = 1200.99
    var altura = 1.8f
    var direccionCasa = "Ayende 250"
    var resultado = true

    var nombreCompleto : String = "a"
    var edad : Int = 21

    var nombreCampoTexto : EditText ?= null
    var boton : Button ?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        botonsaludador.setOnClickListener {
            var nombre = camponombrepersona.text.toString()

            if(nombre.isEmpty()){
                AlertDialog.Builder(this)
                    .setTitle("ERROR")
                    .setMessage("Debes poner un nombre")
                    .setPositiveButton("OK", { d, i -> d.dismiss()})
                    .show()
            }else {

                val alerta = AlertDialog.Builder(this)
                alerta.setTitle("ATENCION")
                alerta.setMessage("Hola, ${nombre} como estas")

                alerta.setPositiveButton("ACEPTAR") { d, i ->
                    d.dismiss()
                }

                alerta.setNegativeButton("CANCELAR") { d, i ->
                    d.cancel()
                }

                //alerta.setNeutralButton()

                alerta.show()
            }
        }

        radioButton.setOnClickListener {
            Toast.makeText(this, "Usted es casado", Toast.LENGTH_SHORT).show()
        }

        radioButton2.setOnClickListener{
            Toast.makeText(this, "Usted es soltero", Toast.LENGTH_SHORT).show()
        }
    }
}